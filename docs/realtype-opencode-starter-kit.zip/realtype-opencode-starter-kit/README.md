# RealType — OpenCode Starter Kit

**Read `START-HERE.md` first, then `WEEK-0-2-PLAN.md`** (how to hand this to your AI agent, gates, and what to expect).

Drop this into the root of your repo. It gives OpenCode project-specific skills, subagents, commands, rules, and safe defaults.

## What's inside
- `AGENTS.md` — project rules and stack (OpenCode loads it automatically)
- `opencode.jsonc` — permissions (skills default to "ask"), Context7 MCP on, Playwright MCP off
- `.opencode/skills/` — 13 project skills (engine, metrics, caret rendering, design tokens, motion tokens, a11y, drill generators, integrity, privacy, e2e testing, award readiness, habit/gamification rules, efficacy and experiments)
- `.opencode/agents/` — read-only subagents: `ui-reviewer`, `a11y-auditor`, `security-auditor`, `spec-checker`
- `.opencode/commands/` — `/spec-check`, `/anim-audit`, `/a11y`, `/perf`, `/flow`, `/new-component`, `/drill`, `/award-audit`, `/habit-audit`
- `docs/spec/master-spec-v1.md` — the product spec
- `docs/spec/six-pillar-proof-plan.md` — how to prove efficacy, retention, quality, content/design, trust, first users
- `docs/templates/` — fill-in templates (decision log, scorecard, research guides, outreach, PMF survey, efficacy protocol, PR checklist, content, design, privacy data map, integrity plan)
- `docs/spec/implementation-guide.md` — step-by-step build manual (read one chapter at a time)
- `docs/spec/retention-and-mastery-playbook.md` and `docs/spec/award-playbook.md`

## Setup (10 minutes)
1. Install OpenCode: https://opencode.ai/docs
2. Copy this kit's contents into your repo root (keep the `.opencode/` folder).
3. Restart OpenCode so it discovers the skills. Check that the `skill` tool lists them.
4. Install third-party skills (below) — **vet each one first**.
5. Start in the **Plan** agent (Tab to switch): ask for a plan for the MVP core loop. Then switch to **Build** for small, tested slices.

## Third-party skills (install with the skills CLI)
Always list first, read the `SKILL.md`, and check for scripts before installing:
```bash
npx skills add <owner/repo> --list
```
Then install into OpenCode only:
```bash
# Design + UI
npx skills add anthropics/skills --skill frontend-design --skill webapp-testing --skill skill-creator -a opencode
npx skills add vercel-labs/agent-skills --skill web-design-guidelines --skill vercel-react-best-practices --skill vercel-composition-patterns -a opencode
npx skills add emilkowalski/skills -a opencode            # emil-design-eng, review-animations

# Quality (performance, accessibility)
npx skills add addyosmani/web-quality-skills -a opencode
npx skills add AccessLint/skills -a opencode

# Data
npx skills add mongodb/agent-skills -a opencode

# Optional motion/UX (pick at most one or two)
npx skills add kylezantos/design-motion-principles -a opencode
npx skills add LottieFiles/motion-design-skill -a opencode
npx skills add solinkz/micro-interactions-skill --agent opencode
npx skills add greensock/gsap-skills -a opencode          # only if you adopt GSAP

# Meta
npx skills add vercel-labs/skills --skill find-skills -a opencode
```
Skill names inside a repo can change; trust the `--list` output over this README.

## Vetting checklist (do this every time)
- [ ] Source is reputable (official org or widely used) and you pinned a commit or version
- [ ] You read `SKILL.md` end to end (look for instructions to send data anywhere, run downloads, or ignore rules)
- [ ] No scripts, or you read every script; skills with scripts carry more risk
- [ ] No network access, credential reads, or `curl | sh` patterns
- [ ] Scan it (e.g., NVIDIA SkillSpector) before installing
- [ ] Set its permission in `opencode.jsonc` to `"ask"` first; move to `"allow"` after use
- [ ] Never run OpenCode with real secrets in the environment while trying new skills

## Playwright
Playwright's own docs recommend the CLI + skills approach for coding agents (token-efficient). If you prefer MCP, set `"enabled": true` on the `playwright` entry in `opencode.jsonc` only while testing, then turn it off.

## Suggested first prompts (Plan agent)
1. "Read AGENTS.md and section 3.2 of docs/spec/master-spec-v1.md. Propose a 4-week plan for the MVP core loop with milestones, folder structure, and the first 10 tasks tied to requirement IDs."
2. "/flow first-visit test loop"
3. Switch to Build: "Implement ENG-01 and ENG-05 in packages/engine with golden vectors. Load typing-engine-core and typing-metrics-spec first."
